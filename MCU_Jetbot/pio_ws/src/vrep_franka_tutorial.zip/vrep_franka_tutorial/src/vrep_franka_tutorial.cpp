#include "vrep_franka_tutorial/franka_controller.hpp"

int main(int argc, char** argv)
{
  ros::init(argc,argv,"dwa_sim");
  DWA_Planner sim_dwa;
  sim_dwa.process();
  return 0;
}
